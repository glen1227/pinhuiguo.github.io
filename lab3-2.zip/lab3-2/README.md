# lab3.2

A Pen created on CodePen.io. Original URL: [https://codepen.io/len-G/pen/mybvbBe](https://codepen.io/len-G/pen/mybvbBe).

